
from LongNet.attention import ParallelWrapper, DilatedAttention
# from LongNet.model import LongNetTokenizer, LongNet, DecoderConfig, Decoder, DilatedLongNet

# from LongNet.iterations import DynamicDilatedAttention, DilatedAttentionOld, DilatedAttentionOP